#GIFimgeObject
MOD UNDER DEVELOPMENT
MOD UNDER DEVELOPMENT
You will finally be able to add an animated image for your map (gif).



